#include <stdio.h>

int main(int argc, char *argv[])
{
    int current_year = 2024;
    int birth_year;
    int had_birthday;           /* used as boolean */

    /* TODO: ask what year the user was born in */

    /* TODO: ask whether the user has had their birthday yet this year */

    /* TODO: compute and display the user's age */

    return 0;
}
